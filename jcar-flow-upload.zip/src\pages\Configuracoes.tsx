import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building, Bell, MessageSquare, Users, Shield } from 'lucide-react';
import { useMecanicos } from '@/hooks/useMecanicos';

export default function Configuracoes() {
  const { data: mecanicos } = useMecanicos();

  return (
    <MainLayout>
      <Header
        title="Configurações"
        subtitle="Configure o sistema conforme suas necessidades"
      />

      <Tabs defaultValue="empresa" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="empresa" className="gap-2">
            <Building className="w-4 h-4" />
            Empresa
          </TabsTrigger>
          <TabsTrigger value="notificacoes" className="gap-2">
            <Bell className="w-4 h-4" />
            Notificações
          </TabsTrigger>
          <TabsTrigger value="whatsapp" className="gap-2">
            <MessageSquare className="w-4 h-4" />
            WhatsApp
          </TabsTrigger>
          <TabsTrigger value="equipe" className="gap-2">
            <Users className="w-4 h-4" />
            Equipe
          </TabsTrigger>
        </TabsList>

        {/* Empresa */}
        <TabsContent value="empresa">
          <div className="glass-card p-6 space-y-6">
            <h3 className="text-lg font-semibold text-foreground">Dados da Empresa</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Nome da Empresa</Label>
                <Input defaultValue="JCAR AUTOMÁTICOS" className="input-field" />
              </div>
              <div className="space-y-2">
                <Label>CNPJ</Label>
                <Input placeholder="00.000.000/0000-00" className="input-field" />
              </div>
              <div className="space-y-2">
                <Label>Telefone</Label>
                <Input placeholder="(00) 00000-0000" className="input-field" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input type="email" placeholder="contato@jcar.com.br" className="input-field" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Endereço</Label>
                <Input placeholder="Rua, número, bairro, cidade - UF" className="input-field" />
              </div>
            </div>

            <Button variant="glow">Salvar Alterações</Button>
          </div>
        </TabsContent>

        {/* Notificações */}
        <TabsContent value="notificacoes">
          <div className="glass-card p-6 space-y-6">
            <h3 className="text-lg font-semibold text-foreground">Preferências de Notificação</h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Nova OS criada</p>
                  <p className="text-sm text-muted-foreground">Receber notificação quando uma nova OS for aberta</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">OS atrasada</p>
                  <p className="text-sm text-muted-foreground">Alertar quando uma OS passar da data prevista</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Estoque baixo</p>
                  <p className="text-sm text-muted-foreground">Alertar quando peças atingirem o estoque mínimo</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Orçamento aprovado</p>
                  <p className="text-sm text-muted-foreground">Notificar quando cliente aprovar orçamento</p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </div>
        </TabsContent>

        {/* WhatsApp */}
        <TabsContent value="whatsapp">
          <div className="glass-card p-6 space-y-6">
            <h3 className="text-lg font-semibold text-foreground">Integração WhatsApp</h3>

            <div className="p-4 bg-warning/10 border border-warning/30 rounded-lg">
              <p className="text-sm text-warning">
                Para integrar com o WhatsApp Business API, é necessário configurar uma conta no Meta Business.
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Número do WhatsApp Business</Label>
                <Input placeholder="+55 11 99999-9999" className="input-field" />
              </div>

              <div className="space-y-2">
                <Label>Token de Acesso</Label>
                <Input type="password" placeholder="••••••••••••••••" className="input-field" />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Mensagens Automáticas</h4>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Confirmação de OS</p>
                  <p className="text-sm text-muted-foreground">Enviar confirmação quando OS for criada</p>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Envio de Orçamento</p>
                  <p className="text-sm text-muted-foreground">Enviar orçamento automaticamente</p>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Veículo pronto</p>
                  <p className="text-sm text-muted-foreground">Avisar quando veículo estiver pronto para retirada</p>
                </div>
                <Switch />
              </div>
            </div>

            <Button variant="glow">Salvar Configurações</Button>
          </div>
        </TabsContent>

        {/* Equipe */}
        <TabsContent value="equipe">
          <div className="glass-card p-6 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground">Mecânicos</h3>
              <Button variant="outline" size="sm">Adicionar Mecânico</Button>
            </div>

            <div className="space-y-3">
              {mecanicos?.map((mecanico) => (
                <div
                  key={mecanico.id}
                  className="flex items-center justify-between p-4 bg-muted/30 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="font-semibold text-primary">
                        {mecanico.nome.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{mecanico.nome}</p>
                      <p className="text-sm text-muted-foreground">{mecanico.especialidade}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`status-badge ${mecanico.ativo ? 'bg-success/20 text-success' : 'bg-muted text-muted-foreground'}`}>
                      {mecanico.ativo ? 'Ativo' : 'Inativo'}
                    </span>
                    <Button variant="ghost" size="sm">Editar</Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}
