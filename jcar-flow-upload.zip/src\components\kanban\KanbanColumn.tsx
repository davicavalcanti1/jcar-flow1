import { OrdemServico, OSStatus } from '@/types';
import { KanbanCard } from './KanbanCard';
import { cn } from '@/lib/utils';

interface KanbanColumnProps {
  status: OSStatus;
  config: { label: string; color: string; bgColor: string };
  ordens: OrdemServico[];
  onDragStart: (os: OrdemServico) => void;
  onDragEnd: () => void;
  onDrop: () => void;
  isDragging: boolean;
  onCardClick: (os: OrdemServico) => void;
}

export function KanbanColumn({
  status,
  config,
  ordens,
  onDragStart,
  onDragEnd,
  onDrop,
  isDragging,
  onCardClick
}: KanbanColumnProps) {
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    onDrop();
  };

  return (
    <div
      className={cn(
        "kanban-column w-full transition-all duration-200 flex flex-col",
        isDragging && "border-dashed border-primary/50"
      )}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className={cn("status-badge", config.bgColor, config.color)}>
            {config.label}
          </span>
        </div>
        <span className="text-sm text-muted-foreground font-medium">
          {ordens.length}
        </span>
      </div>

      {/* Cards */}
      <div className="space-y-3">
        {ordens.map((os) => (
          <KanbanCard
            key={os.id}
            os={os}
            onDragStart={() => onDragStart(os)}
            onDragEnd={onDragEnd}
            onClick={() => onCardClick(os)}
          />
        ))}

        {ordens.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border/50 rounded-lg">
            Nenhuma OS
          </div>
        )}
      </div>
    </div>
  );
}
