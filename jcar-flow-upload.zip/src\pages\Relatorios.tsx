import { useMemo } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Download, FileSpreadsheet, FileText, Loader2 } from 'lucide-react';
import { useOrdensServico } from '@/hooks/useOrdensServico';
import { format, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, subDays, isSameDay, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Relatorios() {
  const { data: ordens, isLoading } = useOrdensServico();

  // Calculate Faturamento Mensal (Last 6 months)
  const faturamentoData = useMemo(() => {
    if (!ordens) return [];

    const today = new Date();
    const data = [];

    for (let i = 5; i >= 0; i--) {
      const date = subMonths(today, i);
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);
      const monthName = format(date, 'MMM', { locale: ptBR });

      const total = ordens
        .filter(os => {
          const osDate = new Date(os.created_at);
          return osDate >= monthStart && osDate <= monthEnd;
        })
        .reduce((acc, os) => acc + (os.valor_total || 0), 0);

      data.push({ mes: monthName.charAt(0).toUpperCase() + monthName.slice(1), valor: total });
    }

    return data;
  }, [ordens]);

  // Calculate Status Distribution
  const statusData = useMemo(() => {
    if (!ordens) return [];

    const statusCounts = ordens.reduce((acc, os) => {
      const status = os.status;
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const statusMap: Record<string, { name: string; color: string }> = {
      'a_receber': { name: 'A Receber', color: 'hsl(217, 33%, 40%)' },
      'aguardando_aprovacao': { name: 'Aguard. Aprovação', color: 'hsl(38, 92%, 50%)' },
      'aguardando_peca': { name: 'Aguard. Peça', color: 'hsl(24, 95%, 53%)' },
      'em_execucao': { name: 'Em Execução', color: 'hsl(199, 89%, 48%)' },
      'finalizado': { name: 'Finalizado', color: 'hsl(142, 76%, 36%)' },
      'pronto_retirada': { name: 'Pronto', color: 'hsl(160, 84%, 39%)' },
    };

    return Object.entries(statusCounts).map(([key, value]) => ({
      name: statusMap[key]?.name || key,
      value,
      color: statusMap[key]?.color || 'hsl(217, 33%, 40%)',
    }));
  }, [ordens]);

  // Calculate OS per Day (Last 7 days)
  const osData = useMemo(() => {
    if (!ordens) return [];

    const today = new Date();
    const last7Days = eachDayOfInterval({
      start: subDays(today, 6),
      end: today,
    });

    return last7Days.map(day => {
      const dayName = format(day, 'EEE', { locale: ptBR });

      const abertas = ordens.filter(os =>
        isSameDay(new Date(os.created_at), day)
      ).length;

      const finalizadas = ordens.filter(os =>
        os.status === 'finalizado' &&
        os.data_conclusao &&
        isSameDay(new Date(os.data_conclusao), day)
      ).length;

      return {
        dia: dayName.charAt(0).toUpperCase() + dayName.slice(1),
        abertas,
        finalizadas
      };
    });
  }, [ordens]);

  if (isLoading) {
    return (
      <MainLayout>
        <Header title="Relatórios" subtitle="Análises e métricas da oficina" />
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <Header
        title="Relatórios"
        subtitle="Análises e métricas da oficina"
      />

      {/* Export Buttons */}
      <div className="flex flex-wrap gap-3 mb-6">
        <Button variant="outline" className="gap-2">
          <FileSpreadsheet className="w-4 h-4" />
          Exportar Excel
        </Button>
        <Button variant="outline" className="gap-2">
          <FileText className="w-4 h-4" />
          Exportar PDF
        </Button>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Faturamento */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground">Faturamento Mensal</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={faturamentoData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 20%)" />
              <XAxis dataKey="mes" stroke="hsl(215, 20%, 55%)" />
              <YAxis stroke="hsl(215, 20%, 55%)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(222, 47%, 10%)',
                  border: '1px solid hsl(217, 33%, 17%)',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Faturamento']}
              />
              <Bar dataKey="valor" fill="hsl(24, 95%, 53%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Status Distribution */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground">Status das OS</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(222, 47%, 10%)',
                  border: '1px solid hsl(217, 33%, 17%)',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [value, 'Quantidade']}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap justify-center gap-4 mt-4">
            {statusData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-muted-foreground">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* OS por Dia */}
        <div className="glass-card p-6 lg:col-span-2">
          <h3 className="text-lg font-semibold mb-4 text-foreground">Ordens de Serviço - Última Semana</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={osData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 20%)" />
              <XAxis dataKey="dia" stroke="hsl(215, 20%, 55%)" />
              <YAxis stroke="hsl(215, 20%, 55%)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(222, 47%, 10%)',
                  border: '1px solid hsl(217, 33%, 17%)',
                  borderRadius: '8px'
                }}
              />
              <Line
                type="monotone"
                dataKey="abertas"
                stroke="hsl(24, 95%, 53%)"
                strokeWidth={2}
                dot={{ fill: 'hsl(24, 95%, 53%)' }}
                name="Criadas"
              />
              <Line
                type="monotone"
                dataKey="finalizadas"
                stroke="hsl(142, 76%, 36%)"
                strokeWidth={2}
                dot={{ fill: 'hsl(142, 76%, 36%)' }}
                name="Finalizadas"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </MainLayout>
  );
}
