import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { StatCard } from '@/components/dashboard/StatCard';
import { KanbanBoard } from '@/components/kanban/KanbanBoard';
import { NovaOSDialog } from '@/components/os/NovaOSDialog';
import { Clipboard, Clock, CheckCircle, AlertTriangle, DollarSign, Users, Loader2 } from 'lucide-react';
import { useOrdensServico } from '@/hooks/useOrdensServico';
import { useClientes } from '@/hooks/useClientes';
import { useEstoque } from '@/hooks/useEstoque';
import { isSameDay, parseISO } from 'date-fns';

export default function Dashboard() {
  const [showNovaOS, setShowNovaOS] = useState(false);

  const { data: ordens, isLoading: loadingOrdens } = useOrdensServico();
  const { data: clientes, isLoading: loadingClientes } = useClientes();
  const { data: estoque, isLoading: loadingEstoque } = useEstoque();

  // Calculate stats
  const osAbertas = ordens?.filter(os => os.status !== 'finalizado' && os.status !== 'pronto_retirada').length || 0;
  const emExecucao = ordens?.filter(os => os.status === 'em_execucao').length || 0;

  const hoje = new Date();
  const finalizadasHoje = ordens?.filter(os => {
    if (os.status !== 'finalizado' || !os.dataFinal) return false;
    // Handle both Date objects and ISO strings if necessary, though adapter converts to Date
    const dataFinal = os.dataFinal instanceof Date ? os.dataFinal : parseISO(os.dataFinal as unknown as string);
    return isSameDay(dataFinal, hoje);
  }).length || 0;

  const aguardandoPeca = ordens?.filter(os => os.status === 'aguardando_peca').length || 0;

  // Calculate total revenue (sum of finalized OS)
  // Note: We need to ensure we have the value. For now using valorTotal from OS if available.
  const faturamentoTotal = ordens?.reduce((acc, os) => {
    if (os.status === 'finalizado') {
      return acc + (os.valorTotal || 0);
    }
    return acc;
  }, 0) || 0;

  const clientesAtivos = clientes?.length || 0;
  const estoqueBaixo = estoque?.filter(p => p.quantidade_minima && p.quantidade <= p.quantidade_minima).length || 0;

  if (loadingOrdens || loadingClientes || loadingEstoque) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <Header
        title="Dashboard"
        subtitle="Visão geral da oficina"
        onNewOS={() => setShowNovaOS(true)}
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
        <StatCard
          title="OS Abertas"
          value={osAbertas}
          icon={Clipboard}
          variant="primary"
        />
        <StatCard
          title="Em Execução"
          value={emExecucao}
          icon={Clock}
          variant="warning"
        />
        <StatCard
          title="Finalizadas Hoje"
          value={finalizadasHoje}
          icon={CheckCircle}
          variant="success"
        />
        <StatCard
          title="Aguardando Peça"
          value={aguardandoPeca}
          icon={AlertTriangle}
          variant="destructive"
        />
        <StatCard
          title="Faturamento Total"
          value={`R$ ${faturamentoTotal.toLocaleString('pt-BR')}`}
          icon={DollarSign}
        />
        <StatCard
          title="Clientes"
          value={clientesAtivos}
          icon={Users}
        />
      </div>

      {/* Kanban Section */}
      <section>
        <h2 className="text-lg font-semibold mb-4 text-foreground">
          Kanban de Serviços
        </h2>
        <KanbanBoard />
      </section>

      {/* Nova OS Dialog */}
      <NovaOSDialog open={showNovaOS} onOpenChange={setShowNovaOS} />
    </MainLayout>
  );
}
