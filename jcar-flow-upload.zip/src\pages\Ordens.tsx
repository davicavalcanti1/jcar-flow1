import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { KanbanBoard } from '@/components/kanban/KanbanBoard';
import { NovaOSDialog } from '@/components/os/NovaOSDialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter, LayoutGrid, List } from 'lucide-react';
import { useMecanicos } from '@/hooks/useMecanicos';

export default function Ordens() {
  const [showNovaOS, setShowNovaOS] = useState(false);
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const { data: mecanicos } = useMecanicos();

  return (
    <MainLayout>
      <Header
        title="Ordens de Serviço"
        subtitle="Gerencie todas as ordens de serviço"
        onNewOS={() => setShowNovaOS(true)}
      />

      {/* Filters */}
      <div className="glass-card p-4 mb-6">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por número, cliente ou placa..."
              className="pl-10 input-field"
            />
          </div>

          <Select>
            <SelectTrigger className="w-[180px] input-field">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="a_receber">A Receber</SelectItem>
              <SelectItem value="aguardando_aprovacao">Aguardando Aprovação</SelectItem>
              <SelectItem value="aguardando_peca">Aguardando Peça</SelectItem>
              <SelectItem value="em_execucao">Em Execução</SelectItem>
              <SelectItem value="finalizado">Finalizado</SelectItem>
              <SelectItem value="pronto_retirada">Pronto para Retirada</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-[180px] input-field">
              <SelectValue placeholder="Mecânico" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              {mecanicos?.map(m => (
                <SelectItem key={m.id} value={m.id}>{m.nome}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center gap-1 ml-auto">
            <Button
              variant={viewMode === 'kanban' ? 'secondary' : 'ghost'}
              size="icon"
              onClick={() => setViewMode('kanban')}
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'secondary' : 'ghost'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      {viewMode === 'kanban' ? (
        <KanbanBoard />
      ) : (
        <div className="glass-card p-6">
          <p className="text-muted-foreground text-center py-8">
            Visualização em lista - Em breve
          </p>
        </div>
      )}

      <NovaOSDialog open={showNovaOS} onOpenChange={setShowNovaOS} />
    </MainLayout>
  );
}
