import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Mecanico {
    id: string;
    nome: string;
    especialidade: string | null;
    telefone: string | null;
    ativo: boolean | null;
    created_at: string;
}

export interface CreateMecanicoData {
    nome: string;
    especialidade?: string;
    telefone?: string;
    ativo?: boolean;
}

// Fetch all active mechanics
export function useMecanicos() {
    return useQuery({
        queryKey: ['mecanicos'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('mecanicos')
                .select('*')
                .eq('ativo', true)
                .order('nome');

            if (error) throw error;
            return data as Mecanico[];
        },
    });
}

// Create new mechanic
export function useCreateMecanico() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (newMecanico: CreateMecanicoData) => {
            const { data, error } = await supabase
                .from('mecanicos')
                .insert([{ ...newMecanico, ativo: true }])
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['mecanicos'] });
            toast.success('Mecânico cadastrado com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao cadastrar mecânico: ' + error.message);
        },
    });
}

// Update mechanic
export function useUpdateMecanico() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, ...updates }: Partial<Mecanico> & { id: string }) => {
            const { data, error } = await supabase
                .from('mecanicos')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['mecanicos'] });
            toast.success('Mecânico atualizado com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao atualizar mecânico: ' + error.message);
        },
    });
}
