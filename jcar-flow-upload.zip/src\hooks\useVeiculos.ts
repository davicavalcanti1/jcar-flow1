import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Veiculo {
    id: string;
    cliente_id: string | null;
    modelo: string;
    placa: string;
    marca: string | null;
    ano: number | null;
    cor: string | null;
    created_at: string;
    updated_at: string;
}

export interface VeiculoWithCliente extends Veiculo {
    cliente?: {
        id: string;
        nome: string;
    };
}

export interface CreateVeiculoData {
    cliente_id: string;
    modelo: string;
    placa: string;
    marca?: string;
    ano?: number;
    cor?: string;
}

// Fetch all vehicles with client info
export function useVeiculos() {
    return useQuery({
        queryKey: ['veiculos'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('veiculos')
                .select(`
          *,
          cliente:clientes(id, nome)
        `)
                .order('modelo');

            if (error) throw error;
            return data as VeiculoWithCliente[];
        },
    });
}

// Fetch vehicles by client
export function useVeiculosByCliente(clienteId: string | null) {
    return useQuery({
        queryKey: ['veiculos', 'cliente', clienteId],
        queryFn: async () => {
            if (!clienteId) return [];

            const { data, error } = await supabase
                .from('veiculos')
                .select('*')
                .eq('cliente_id', clienteId)
                .order('modelo');

            if (error) throw error;
            return data as Veiculo[];
        },
        enabled: !!clienteId,
    });
}

// Create new vehicle
export function useCreateVeiculo() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (newVeiculo: CreateVeiculoData) => {
            const { data, error } = await supabase
                .from('veiculos')
                .insert([newVeiculo])
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['veiculos'] });
            toast.success('Veículo cadastrado com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao cadastrar veículo: ' + error.message);
        },
    });
}

// Update vehicle
export function useUpdateVeiculo() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, ...updates }: Partial<Veiculo> & { id: string }) => {
            const { data, error } = await supabase
                .from('veiculos')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['veiculos'] });
            toast.success('Veículo atualizado com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao atualizar veículo: ' + error.message);
        },
    });
}

// Delete vehicle
export function useDeleteVeiculo() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase
                .from('veiculos')
                .delete()
                .eq('id', id);

            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['veiculos'] });
            toast.success('Veículo excluído com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao excluir veículo: ' + error.message);
        },
    });
}
