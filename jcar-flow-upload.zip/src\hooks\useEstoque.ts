import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Peca {
    id: string;
    codigo: string | null;
    nome: string;
    quantidade: number;
    quantidade_minima: number | null;
    preco_compra: number | null;
    preco_venda: number | null;
    fornecedor: string | null;
    created_at: string;
    updated_at: string;
}

export interface CreatePecaData {
    codigo?: string;
    nome: string;
    quantidade?: number;
    quantidade_minima?: number;
    preco_compra?: number;
    preco_venda?: number;
    fornecedor?: string;
}

// Fetch all inventory items
export function useEstoque() {
    return useQuery({
        queryKey: ['estoque'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('estoque')
                .select('*')
                .order('nome');

            if (error) throw error;
            return data as Peca[];
        },
    });
}

// Create new part
export function useCreatePeca() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (newPeca: CreatePecaData) => {
            // Generate code if not provided
            const codigo = newPeca.codigo || `PC-${Date.now().toString().slice(-6)}`;

            const { data, error } = await supabase
                .from('estoque')
                .insert([{ ...newPeca, codigo, quantidade: newPeca.quantidade || 0 }])
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['estoque'] });
            toast.success('Peça cadastrada com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao cadastrar peça: ' + error.message);
        },
    });
}

// Update part
export function useUpdatePeca() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, ...updates }: Partial<Peca> & { id: string }) => {
            const { data, error } = await supabase
                .from('estoque')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['estoque'] });
            toast.success('Peça atualizada com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao atualizar peça: ' + error.message);
        },
    });
}

// Delete part
export function useDeletePeca() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase
                .from('estoque')
                .delete()
                .eq('id', id);

            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['estoque'] });
            toast.success('Peça excluída com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao excluir peça: ' + error.message);
        },
    });
}
