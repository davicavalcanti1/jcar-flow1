import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useEstoque, useDeletePeca } from '@/hooks/useEstoque';
import { NovaPecaDialog } from '@/components/estoque/NovaPecaDialog';
import { Search, Plus, AlertTriangle, Package, TrendingUp, Loader2, MoreVertical, Edit, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Database } from '@/integrations/supabase/types';

type Peca = Database['public']['Tables']['estoque']['Row'];

export default function Estoque() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showNovaPeca, setShowNovaPeca] = useState(false);
  const [pecaToEdit, setPecaToEdit] = useState<Peca | null>(null);
  const [pecaToDelete, setPecaToDelete] = useState<Peca | null>(null);

  const { data: pecas, isLoading } = useEstoque();
  const deletePeca = useDeletePeca();

  const filteredPecas = pecas?.filter(peca =>
    peca.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (peca.codigo && peca.codigo.toLowerCase().includes(searchTerm.toLowerCase()))
  ) || [];

  const handleEdit = (peca: Peca) => {
    setPecaToEdit(peca);
    setShowNovaPeca(true);
  };

  const handleDelete = async () => {
    if (pecaToDelete) {
      await deletePeca.mutateAsync(pecaToDelete.id);
      setPecaToDelete(null);
    }
  };

  const handleDialogClose = (open: boolean) => {
    setShowNovaPeca(open);
    if (!open) {
      setPecaToEdit(null);
    }
  };

  const totalItens = pecas?.reduce((acc, p) => acc + p.quantidade, 0) || 0;
  const itensBaixos = pecas?.filter(p => p.quantidade_minima && p.quantidade <= p.quantidade_minima).length || 0;
  const valorEstoque = pecas?.reduce((acc, p) => acc + (p.quantidade * (p.preco_compra || 0)), 0) || 0;

  return (
    <MainLayout>
      <Header
        title="Estoque"
        subtitle="Controle de peças e produtos"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Package className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total de Itens</p>
              <p className="text-2xl font-bold text-foreground">{totalItens}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-destructive/20">
              <AlertTriangle className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Estoque Baixo</p>
              <p className="text-2xl font-bold text-foreground">{itensBaixos}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-success/20">
              <TrendingUp className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Valor em Estoque</p>
              <p className="text-2xl font-bold text-foreground">
                R$ {valorEstoque.toLocaleString('pt-BR')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Actions Bar */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar peça..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 input-field"
          />
        </div>
        <Button variant="glow" className="gap-2" onClick={() => setShowNovaPeca(true)}>
          <Plus className="w-4 h-4" />
          Nova Peça
        </Button>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {/* Table */}
      {!isLoading && (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50">
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Código</th>
                  <th className="text-left p-4 text-sm font-medium text-muted-foreground">Peça</th>
                  <th className="text-center p-4 text-sm font-medium text-muted-foreground">Quantidade</th>
                  <th className="text-center p-4 text-sm font-medium text-muted-foreground">Mínimo</th>
                  <th className="text-right p-4 text-sm font-medium text-muted-foreground">Preço Compra</th>
                  <th className="text-right p-4 text-sm font-medium text-muted-foreground">Preço Venda</th>
                  <th className="text-center p-4 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="w-[50px]"></th>
                </tr>
              </thead>
              <tbody>
                {filteredPecas.map((peca) => {
                  const isLow = peca.quantidade_minima && peca.quantidade <= peca.quantidade_minima;
                  return (
                    <tr
                      key={peca.id}
                      className="border-b border-border/30 hover:bg-muted/30 transition-colors"
                    >
                      <td className="p-4">
                        <span className="font-mono text-sm text-primary">{peca.codigo}</span>
                      </td>
                      <td className="p-4">
                        <span className="font-medium text-foreground">{peca.nome}</span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={cn(
                          "font-semibold",
                          isLow ? "text-destructive" : "text-foreground"
                        )}>
                          {peca.quantidade}
                        </span>
                      </td>
                      <td className="p-4 text-center text-muted-foreground">
                        {peca.quantidade_minima || '-'}
                      </td>
                      <td className="p-4 text-right text-muted-foreground">
                        R$ {peca.preco_compra?.toFixed(2) || '0.00'}
                      </td>
                      <td className="p-4 text-right font-medium text-foreground">
                        R$ {peca.preco_venda?.toFixed(2) || '0.00'}
                      </td>
                      <td className="p-4">
                        <div className="flex justify-center">
                          {isLow ? (
                            <span className="status-badge bg-destructive/20 text-destructive flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              Baixo
                            </span>
                          ) : (
                            <span className="status-badge bg-success/20 text-success">
                              OK
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(peca)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => setPecaToDelete(peca)}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {!isLoading && filteredPecas.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhuma peça encontrada</p>
        </div>
      )}

      <NovaPecaDialog
        open={showNovaPeca}
        onOpenChange={handleDialogClose}
        pecaToEdit={pecaToEdit}
      />

      <AlertDialog open={!!pecaToDelete} onOpenChange={(open) => !open && setPecaToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Peça</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a peça <strong>{pecaToDelete?.nome}</strong>?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
