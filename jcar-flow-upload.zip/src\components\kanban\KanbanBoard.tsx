import { useState } from 'react';
import { OSStatus } from '@/hooks/useOrdensServico';
import { useOrdensServico, useUpdateOrdemServicoStatus, OrdemServicoWithRelations } from '@/hooks/useOrdensServico';
import { STATUS_CONFIG } from '@/types';
import { KanbanColumn } from './KanbanColumn';
import { Loader2 } from 'lucide-react';
import { OSDetailsDialog } from '@/components/os/OSDetailsDialog';

const COLUMN_ORDER: OSStatus[] = [
  'a_receber',
  'aguardando_aprovacao',
  'aguardando_peca',
  'em_execucao',
  'finalizado',
  'pronto_retirada',
];

// Adapter to convert Supabase OS to frontend format
const adaptOrdemServico = (os: OrdemServicoWithRelations): any => ({
  id: os.id,
  numero: os.numero,
  clienteId: os.cliente_id || '',
  veiculoId: os.veiculo_id || '',
  cliente: os.cliente,
  veiculo: os.veiculo,
  descricao: os.descricao || '',
  status: os.status as OSStatus,
  dataEntrada: new Date(os.data_entrada),
  dataPrevista: os.data_prevista ? new Date(os.data_prevista) : undefined,
  dataFinal: os.data_conclusao ? new Date(os.data_conclusao) : undefined,
  mecanico: os.mecanico?.nome,
  valorTotal: os.valor_total || 0,
});

export function KanbanBoard() {
  const { data: ordensData, isLoading } = useOrdensServico();
  const updateStatus = useUpdateOrdemServicoStatus();
  const [draggedOS, setDraggedOS] = useState<any | null>(null);
  const [selectedOS, setSelectedOS] = useState<any | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const ordens = ordensData?.map(adaptOrdemServico) || [];

  const handleDragStart = (os: any) => {
    setDraggedOS(os);
  };

  const handleDragEnd = () => {
    setDraggedOS(null);
  };

  const handleDrop = async (newStatus: OSStatus) => {
    if (!draggedOS) return;

    // Optimistic update - update UI immediately
    setDraggedOS(null);

    // Update in database
    try {
      await updateStatus.mutateAsync({
        id: draggedOS.id,
        status: newStatus,
      });
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleCardClick = (os: any) => {
    setSelectedOS(os);
    setDetailsOpen(true);
  };

  const getOSByStatus = (status: OSStatus) =>
    ordens.filter(os => os.status === status);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <div className="h-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 min-h-[calc(100vh-200px)]">
          {COLUMN_ORDER.map((status) => (
            <KanbanColumn
              key={status}
              status={status}
              config={STATUS_CONFIG[status]}
              ordens={getOSByStatus(status)}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
              onDrop={() => handleDrop(status)}
              isDragging={draggedOS !== null}
              onCardClick={handleCardClick}
            />
          ))}
        </div>
      </div>

      <OSDetailsDialog
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        os={selectedOS}
      />
    </>
  );
}
