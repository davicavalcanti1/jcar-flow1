import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useVeiculos, useDeleteVeiculo } from '@/hooks/useVeiculos';
import { NovoVeiculoDialog } from '@/components/veiculos/NovoVeiculoDialog';
import { Search, Plus, User, Calendar, Gauge, MoreVertical, Car, Loader2, Edit, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Database } from '@/integrations/supabase/types';

type Veiculo = Database['public']['Tables']['veiculos']['Row'];

export default function Veiculos() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showNovoVeiculo, setShowNovoVeiculo] = useState(false);
  const [veiculoToEdit, setVeiculoToEdit] = useState<Veiculo | null>(null);
  const [veiculoToDelete, setVeiculoToDelete] = useState<Veiculo | null>(null);

  const { data: veiculos, isLoading } = useVeiculos();
  const deleteVeiculo = useDeleteVeiculo();

  const filteredVeiculos = veiculos?.filter(veiculo =>
    veiculo.modelo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    veiculo.placa.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleEdit = (veiculo: Veiculo) => {
    setVeiculoToEdit(veiculo);
    setShowNovoVeiculo(true);
  };

  const handleDelete = async () => {
    if (veiculoToDelete) {
      await deleteVeiculo.mutateAsync(veiculoToDelete.id);
      setVeiculoToDelete(null);
    }
  };

  const handleDialogClose = (open: boolean) => {
    setShowNovoVeiculo(open);
    if (!open) {
      setVeiculoToEdit(null);
    }
  };

  return (
    <MainLayout>
      <Header
        title="Veículos"
        subtitle="Gerencie os veículos cadastrados"
      />

      {/* Actions Bar */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por modelo ou placa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 input-field"
          />
        </div>
        <Button variant="glow" className="gap-2" onClick={() => setShowNovoVeiculo(true)}>
          <Plus className="w-4 h-4" />
          Novo Veículo
        </Button>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {/* Vehicles Grid */}
      {!isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVeiculos.map((veiculo) => {
            return (
              <div key={veiculo.id} className="glass-card p-5 hover:border-primary/30 transition-all duration-200 animate-slide-up">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                      <Car className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{veiculo.modelo}</h3>
                      <p className="text-sm font-mono text-primary">{veiculo.placa}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEdit(veiculo)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => setVeiculoToDelete(veiculo)}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="space-y-2 text-sm">
                  {veiculo.cliente && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <User className="w-4 h-4" />
                      <span>{veiculo.cliente.nome}</span>
                    </div>
                  )}
                  {veiculo.ano && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>Ano: {veiculo.ano}</span>
                    </div>
                  )}
                </div>

                {veiculo.cor && (
                  <div className="mt-4 pt-4 border-t border-border/50">
                    <span className="px-3 py-1 bg-muted rounded-full text-xs text-muted-foreground">
                      {veiculo.cor}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {!isLoading && filteredVeiculos.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhum veículo encontrado</p>
        </div>
      )}

      <NovoVeiculoDialog
        open={showNovoVeiculo}
        onOpenChange={handleDialogClose}
        veiculoToEdit={veiculoToEdit}
      />

      <AlertDialog open={!!veiculoToDelete} onOpenChange={(open) => !open && setVeiculoToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Veículo</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o veículo <strong>{veiculoToDelete?.modelo} - {veiculoToDelete?.placa}</strong>?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
