import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface ItemOrcamento {
    id: string;
    os_id: string | null;
    peca_id: string | null;
    descricao: string;
    quantidade: number;
    valor_unitario: number;
    subtotal: number;
    tipo: 'peca' | 'servico';
    created_at: string;
}

export type NewItemOrcamento = Omit<ItemOrcamento, 'id' | 'created_at' | 'subtotal'>;

export function useItensOrcamento(osId?: string) {
    const queryClient = useQueryClient();

    const { data: itens, isLoading } = useQuery({
        queryKey: ['itens_orcamento', osId],
        queryFn: async () => {
            if (!osId) return [];

            const { data, error } = await supabase
                .from('itens_orcamento')
                .select(`
          *,
          peca:estoque(nome, codigo)
        `)
                .eq('os_id', osId)
                .order('created_at', { ascending: true });

            if (error) {
                toast.error('Erro ao carregar itens do orçamento');
                throw error;
            }

            return data;
        },
        enabled: !!osId,
    });

    const createItem = useMutation({
        mutationFn: async (newItem: NewItemOrcamento) => {
            const subtotal = newItem.quantidade * newItem.valor_unitario;

            const { data, error } = await supabase
                .from('itens_orcamento')
                .insert([{ ...newItem, subtotal }])
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['itens_orcamento', osId] });
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] }); // To update total value
            toast.success('Item adicionado com sucesso!');
        },
        onError: (error) => {
            console.error('Error creating item:', error);
            toast.error('Erro ao adicionar item');
        },
    });

    const deleteItem = useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase
                .from('itens_orcamento')
                .delete()
                .eq('id', id);

            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['itens_orcamento', osId] });
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] });
            toast.success('Item removido com sucesso!');
        },
        onError: (error) => {
            console.error('Error deleting item:', error);
            toast.error('Erro ao remover item');
        },
    });

    return {
        itens,
        isLoading,
        createItem,
        deleteItem,
    };
}
