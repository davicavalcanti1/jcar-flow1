import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useClientes, useDeleteCliente } from '@/hooks/useClientes';
import { useVeiculos } from '@/hooks/useVeiculos';
import { NovoClienteDialog } from '@/components/clientes/NovoClienteDialog';
import { Search, Plus, Phone, Mail, MapPin, Car, MoreVertical, Loader2, Edit, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Database } from '@/integrations/supabase/types';

type Cliente = Database['public']['Tables']['clientes']['Row'];

export default function Clientes() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showNovoCliente, setShowNovoCliente] = useState(false);
  const [clienteToEdit, setClienteToEdit] = useState<Cliente | null>(null);
  const [clienteToDelete, setClienteToDelete] = useState<Cliente | null>(null);

  const { data: clientes, isLoading } = useClientes();
  const { data: veiculos } = useVeiculos();
  const deleteCliente = useDeleteCliente();

  const filteredClientes = clientes?.filter(cliente =>
    cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (cliente.telefone && cliente.telefone.includes(searchTerm))
  ) || [];

  const getVeiculosByClienteId = (clienteId: string) => {
    return veiculos?.filter(v => v.cliente_id === clienteId) || [];
  };

  const handleEdit = (cliente: Cliente) => {
    setClienteToEdit(cliente);
    setShowNovoCliente(true);
  };

  const handleDelete = async () => {
    if (clienteToDelete) {
      await deleteCliente.mutateAsync(clienteToDelete.id);
      setClienteToDelete(null);
    }
  };

  const handleDialogClose = (open: boolean) => {
    setShowNovoCliente(open);
    if (!open) {
      setClienteToEdit(null);
    }
  };

  return (
    <MainLayout>
      <Header
        title="Clientes"
        subtitle="Gerencie sua base de clientes"
      />

      {/* Actions Bar */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 input-field"
          />
        </div>
        <Button variant="glow" className="gap-2" onClick={() => setShowNovoCliente(true)}>
          <Plus className="w-4 h-4" />
          Novo Cliente
        </Button>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {/* Clients Grid */}
      {!isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClientes.map((cliente) => {
            const clienteVeiculos = getVeiculosByClienteId(cliente.id);
            return (
              <div key={cliente.id} className="glass-card p-5 hover:border-primary/30 transition-all duration-200 animate-slide-up">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-lg font-semibold text-primary">
                        {cliente.nome.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{cliente.nome}</h3>
                      <p className="text-xs text-muted-foreground">
                        Cliente desde {format(new Date(cliente.created_at), "MMM yyyy", { locale: ptBR })}
                      </p>
                    </div>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEdit(cliente)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => setClienteToDelete(cliente)}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="space-y-2 text-sm">
                  {cliente.telefone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="w-4 h-4" />
                      <span>{cliente.telefone}</span>
                    </div>
                  )}
                  {cliente.email && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{cliente.email}</span>
                    </div>
                  )}
                  {cliente.endereco && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span className="truncate">{cliente.endereco}</span>
                    </div>
                  )}
                </div>

                {/* Vehicles */}
                <div className="mt-4 pt-4 border-t border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Car className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">
                      {clienteVeiculos.length} veículo{clienteVeiculos.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {clienteVeiculos.slice(0, 2).map(v => (
                      <span
                        key={v.id}
                        className="px-2 py-1 bg-muted rounded text-xs text-muted-foreground"
                      >
                        {v.placa}
                      </span>
                    ))}
                    {clienteVeiculos.length > 2 && (
                      <span className="px-2 py-1 bg-muted rounded text-xs text-muted-foreground">
                        +{clienteVeiculos.length - 2}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {!isLoading && filteredClientes.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhum cliente encontrado</p>
        </div>
      )}

      <NovoClienteDialog
        open={showNovoCliente}
        onOpenChange={handleDialogClose}
        clienteToEdit={clienteToEdit}
      />

      <AlertDialog open={!!clienteToDelete} onOpenChange={(open) => !open && setClienteToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Cliente</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o cliente <strong>{clienteToDelete?.nome}</strong>?
              Esta ação não pode ser desfeita e removerá também todos os veículos associados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
