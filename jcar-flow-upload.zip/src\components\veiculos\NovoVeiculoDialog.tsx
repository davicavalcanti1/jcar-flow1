import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCreateVeiculo, useUpdateVeiculo } from '@/hooks/useVeiculos';
import { useClientes } from '@/hooks/useClientes';
import { Car, User, Hash, Calendar, Palette } from 'lucide-react';
import { Database } from '@/integrations/supabase/types';

type Veiculo = Database['public']['Tables']['veiculos']['Row'];

interface NovoVeiculoDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    veiculoToEdit?: Veiculo | null;
}

export function NovoVeiculoDialog({ open, onOpenChange, veiculoToEdit }: NovoVeiculoDialogProps) {
    const [clienteId, setClienteId] = useState('');
    const [modelo, setModelo] = useState('');
    const [placa, setPlaca] = useState('');
    const [marca, setMarca] = useState('');
    const [ano, setAno] = useState('');
    const [cor, setCor] = useState('');

    const { data: clientes, isLoading: loadingClientes } = useClientes();
    const createVeiculo = useCreateVeiculo();
    const updateVeiculo = useUpdateVeiculo();

    useEffect(() => {
        if (veiculoToEdit) {
            setClienteId(veiculoToEdit.cliente_id || '');
            setModelo(veiculoToEdit.modelo);
            setPlaca(veiculoToEdit.placa);
            setMarca(veiculoToEdit.marca || '');
            setAno(veiculoToEdit.ano ? veiculoToEdit.ano.toString() : '');
            setCor(veiculoToEdit.cor || '');
        } else {
            setClienteId('');
            setModelo('');
            setPlaca('');
            setMarca('');
            setAno('');
            setCor('');
        }
    }, [veiculoToEdit, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!clienteId || !modelo.trim() || !placa.trim()) {
            return;
        }

        try {
            if (veiculoToEdit) {
                await updateVeiculo.mutateAsync({
                    id: veiculoToEdit.id,
                    cliente_id: clienteId,
                    modelo: modelo.trim(),
                    placa: placa.trim().toUpperCase(),
                    marca: marca.trim() || undefined,
                    ano: ano ? parseInt(ano) : undefined,
                    cor: cor.trim() || undefined,
                });
            } else {
                await createVeiculo.mutateAsync({
                    cliente_id: clienteId,
                    modelo: modelo.trim(),
                    placa: placa.trim().toUpperCase(),
                    marca: marca.trim() || undefined,
                    ano: ano ? parseInt(ano) : undefined,
                    cor: cor.trim() || undefined,
                });
            }

            // Reset form and close dialog
            setClienteId('');
            setModelo('');
            setPlaca('');
            setMarca('');
            setAno('');
            setCor('');
            onOpenChange(false);
        } catch (error) {
            console.error(error);
        }
    };

    const formatPlaca = (value: string) => {
        const upper = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (upper.length <= 3) {
            return upper;
        }
        return upper.slice(0, 3) + '-' + upper.slice(3, 7);
    };

    const handlePlacaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const formatted = formatPlaca(e.target.value);
        setPlaca(formatted);
    };

    const isLoading = createVeiculo.isPending || updateVeiculo.isPending;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-md bg-card border-border">
                <DialogHeader>
                    <DialogTitle className="text-xl font-bold flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                            <Car className="w-4 h-4 text-primary" />
                        </div>
                        {veiculoToEdit ? 'Editar Veículo' : 'Novo Veículo'}
                    </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    {/* Cliente */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            Cliente *
                        </Label>
                        <Select value={clienteId} onValueChange={setClienteId} disabled={loadingClientes}>
                            <SelectTrigger className="input-field">
                                <SelectValue placeholder={loadingClientes ? "Carregando..." : "Selecione o cliente"} />
                            </SelectTrigger>
                            <SelectContent>
                                {clientes?.map(cliente => (
                                    <SelectItem key={cliente.id} value={cliente.id}>
                                        {cliente.nome}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Modelo e Marca */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <Car className="w-4 h-4 text-muted-foreground" />
                                Modelo *
                            </Label>
                            <Input
                                value={modelo}
                                onChange={(e) => setModelo(e.target.value)}
                                placeholder="Ex: Civic"
                                className="input-field"
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label>Marca</Label>
                            <Input
                                value={marca}
                                onChange={(e) => setMarca(e.target.value)}
                                placeholder="Ex: Honda"
                                className="input-field"
                            />
                        </div>
                    </div>

                    {/* Placa */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <Hash className="w-4 h-4 text-muted-foreground" />
                            Placa *
                        </Label>
                        <Input
                            value={placa}
                            onChange={handlePlacaChange}
                            placeholder="ABC-1234"
                            className="input-field"
                            maxLength={8}
                            required
                        />
                    </div>

                    {/* Ano e Cor */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <Calendar className="w-4 h-4 text-muted-foreground" />
                                Ano
                            </Label>
                            <Input
                                type="number"
                                value={ano}
                                onChange={(e) => setAno(e.target.value)}
                                placeholder="2020"
                                className="input-field"
                                min="1900"
                                max={new Date().getFullYear() + 1}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <Palette className="w-4 h-4 text-muted-foreground" />
                                Cor
                            </Label>
                            <Input
                                value={cor}
                                onChange={(e) => setCor(e.target.value)}
                                placeholder="Prata"
                                className="input-field"
                            />
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t border-border">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() => onOpenChange(false)}
                            disabled={isLoading}
                        >
                            Cancelar
                        </Button>
                        <Button
                            type="submit"
                            variant="glow"
                            disabled={isLoading || !clienteId || !modelo.trim() || !placa.trim()}
                        >
                            {isLoading ? 'Salvando...' : (veiculoToEdit ? 'Salvar Alterações' : 'Cadastrar Veículo')}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}
