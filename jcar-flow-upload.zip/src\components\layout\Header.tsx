import { Bell, Search, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface HeaderProps {
  title: string;
  subtitle?: string;
  onNewOS?: () => void;
}

export function Header({ title, subtitle, onNewOS }: HeaderProps) {
  return (
    <header className="flex items-center justify-between mb-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{title}</h1>
        {subtitle && (
          <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>
        )}
      </div>
      
      <div className="flex items-center gap-4">
        {/* Search */}
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Buscar OS, cliente ou placa..." 
            className="pl-10 w-64 bg-muted/50 border-border/50 focus:border-primary"
          />
        </div>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full animate-pulse" />
        </Button>

        {/* New OS Button */}
        {onNewOS && (
          <Button variant="glow" onClick={onNewOS} className="gap-2">
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nova OS</span>
          </Button>
        )}
      </div>
    </header>
  );
}
