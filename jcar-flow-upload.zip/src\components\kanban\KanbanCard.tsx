import { OrdemServico } from '@/types';
import { Car, User, Clock, Wrench } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface KanbanCardProps {
  os: OrdemServico;
  onDragStart: () => void;
  onDragEnd: () => void;
  onClick?: () => void;
}

export function KanbanCard({ os, onDragStart, onDragEnd, onClick }: KanbanCardProps) {
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={onClick}
      className="kanban-card animate-scale-in"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-mono text-primary font-semibold">
          {os.numero}
        </span>
        {os.valorTotal > 0 && (
          <span className="text-sm font-semibold text-foreground">
            R$ {os.valorTotal.toLocaleString('pt-BR')}
          </span>
        )}
      </div>

      {/* Description */}
      <p className="text-sm text-foreground mb-3 line-clamp-2">
        {os.descricao}
      </p>

      {/* Details */}
      <div className="space-y-2 text-xs text-muted-foreground">
        {os.cliente && (
          <div className="flex items-center gap-2">
            <User className="w-3 h-3" />
            <span className="truncate">{os.cliente.nome}</span>
          </div>
        )}

        {os.veiculo && (
          <div className="flex items-center gap-2">
            <Car className="w-3 h-3" />
            <span>{os.veiculo.modelo} • {os.veiculo.placa}</span>
          </div>
        )}

        {os.mecanico && (
          <div className="flex items-center gap-2">
            <Wrench className="w-3 h-3" />
            <span>{os.mecanico}</span>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>{format(os.dataEntrada, "dd/MM", { locale: ptBR })}</span>
        </div>
        {os.dataPrevista && (
          <span className="text-xs text-muted-foreground">
            Prev: {format(os.dataPrevista, "dd/MM", { locale: ptBR })}
          </span>
        )}
      </div>
    </div>
  );
}
