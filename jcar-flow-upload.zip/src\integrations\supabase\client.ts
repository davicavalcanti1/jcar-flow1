{
  "name": "Gerar Planilha de Ordens de Serviço",
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": 1
        }
      },
      "id": "Cron",
      "name": "Cron",
      "type": "n8n-nodes-base.cron",
      "typeVersion": 1,
      "position": [
        200,
        300
      ]
    },
    {
      "parameters": {
        "postgresqlQuery": "SELECT \n  id,\n  numero,\n  cliente_id,\n  veiculo_id,\n  mecanico_id,\n  descricao,\n  status,\n  data_entrada,\n  data_prevista,\n  data_conclusao,\n  valor_total,\n  created_at,\n  updated_at\nFROM ordens_servico\nORDER BY data_prevista ASC;"
      },
      "id": "PostgresOS",
      "name": "Postgres - OS",
      "type": "n8n-nodes-base.postgres",
      "typeVersion": 1,
      "position": [
        450,
        300
      ]
    },
    {
      "parameters": {
        "mode": "chat",
        "model": "gpt-4.1-mini",
        "systemMessage": "Você é um assistente que transforma dados em uma tabela organizada. Receberá registros da tabela ordens_servico. Retorne um JSON com o seguinte formato:\n{\n  \"headers\": [\"id\", \"numero\", \"cliente_id\", \"veiculo_id\", \"mecanico_id\", \"descricao\", \"status\", \"data_entrada\", \"data_prevista\", \"data_conclusao\", \"valor_total\", \"created_at\", \"updated_at\"],\n  \"rows\": [ [...], [...], ... ]\n}\nRetorne SOMENTE JSON válido.",
        "input": "Aqui estão os dados da tabela ordens_servico. Converta para o formato de planilha."
      },
      "id": "AgenteIA",
      "name": "agente ia",
      "type": "n8n-nodes-base.openai",
      "typeVersion": 1,
      "position": [
        700,
        300
      ]
    },
    {
      "parameters": {
        "functionCode": "// A saída do Agente IA deve ser JSON válido.\n// Se estiver em string, fazemos parse.\n\nlet content = $node[\"agente ia\"].json;\nlet obj = content;\n\n// Se veio como string (message.content)\nif (content && typeof content === \"string\") {\n  try {\n    obj = JSON.parse(content);\n  } catch (e) {\n    throw new Error(\"OpenAI retornou string não parseável: \" + content.substring(0,300));\n  }\n}\n\n// Valida estrutura\nif (!obj.headers || !obj.rows) {\n  throw new Error(\"Formato inválido. Esperado: { headers: [], rows: [] }\");\n}\n\n// Output 0 → 1 item (apenas headers) — usado pelo Clear\nconst single = [{ json: { headers: obj.headers, rows_count: obj.rows.length }}];\n\n// Output 1 → N items para append\nconst appendItems = obj.rows.map(row => {\n  let item = {};\n  obj.headers.forEach((h, i) => item[h] = row[i] ?? null);\n  return { json: item };\n});\n\nreturn [ single, appendItems ];"
      },
      "id": "FunctionSplit",
      "name": "Function - Split Output",
      "type": "n8n-nodes-base.function",
      "typeVersion": 1,
      "position": [
        950,
        300
      ]
    },
    {
      "parameters": {
        "operation": "clear",
        "sheetId": "",
        "range": "A:Z"
      },
      "id": "SheetsClear",
      "name": "Google Sheets - Clear",
      "type": "n8n-nodes-base.googleSheets",
      "typeVersion": 1,
      "position": [
        1200,
        200
      ]
    },
    {
      "parameters": {
        "operation": "append",
        "sheetId": "",
        "options": {
          "valueInputMode": "RAW"
        }
      },
      "id": "SheetsAppend",
      "name": "Google Sheets - Append",
      "type": "n8n-nodes-base.googleSheets",
      "typeVersion": 1,
      "position": [
        1200,
        400
      ]
    }
  ],
  "connections": {
    "Cron": {
      "main": [
        [
          {
            "node": "Postgres - OS",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Postgres - OS": {
      "main": [
        [
          {
            "node": "agente ia",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "agente ia": {
      "main": [
        [
          {
            "node": "Function - Split Output",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Function - Split Output": {
      "main": [
        [
          {
            "node": "Google Sheets - Clear",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Google Sheets - Append",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
