import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCreateCliente, useUpdateCliente } from '@/hooks/useClientes';
import { User, Phone, Mail, MapPin } from 'lucide-react';
import { Database } from '@/integrations/supabase/types';

type Cliente = Database['public']['Tables']['clientes']['Row'];

interface NovoClienteDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    clienteToEdit?: Cliente | null;
}

export function NovoClienteDialog({ open, onOpenChange, clienteToEdit }: NovoClienteDialogProps) {
    const [nome, setNome] = useState('');
    const [telefone, setTelefone] = useState('');
    const [email, setEmail] = useState('');
    const [endereco, setEndereco] = useState('');

    const createCliente = useCreateCliente();
    const updateCliente = useUpdateCliente();

    useEffect(() => {
        if (clienteToEdit) {
            setNome(clienteToEdit.nome);
            setTelefone(clienteToEdit.telefone || '');
            setEmail(clienteToEdit.email || '');
            setEndereco(clienteToEdit.endereco || '');
        } else {
            setNome('');
            setTelefone('');
            setEmail('');
            setEndereco('');
        }
    }, [clienteToEdit, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!nome.trim()) {
            return;
        }

        try {
            if (clienteToEdit) {
                await updateCliente.mutateAsync({
                    id: clienteToEdit.id,
                    nome: nome.trim(),
                    telefone: telefone.trim() || undefined,
                    email: email.trim() || undefined,
                    endereco: endereco.trim() || undefined,
                });
            } else {
                await createCliente.mutateAsync({
                    nome: nome.trim(),
                    telefone: telefone.trim() || undefined,
                    email: email.trim() || undefined,
                    endereco: endereco.trim() || undefined,
                });
            }

            // Reset form and close dialog
            setNome('');
            setTelefone('');
            setEmail('');
            setEndereco('');
            onOpenChange(false);
        } catch (error) {
            // Error is handled by the hook
            console.error(error);
        }
    };

    const formatPhone = (value: string) => {
        const numbers = value.replace(/\D/g, '');
        if (numbers.length <= 10) {
            return numbers.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
        }
        return numbers.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
    };

    const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const formatted = formatPhone(e.target.value);
        setTelefone(formatted);
    };

    const isLoading = createCliente.isPending || updateCliente.isPending;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-md bg-card border-border">
                <DialogHeader>
                    <DialogTitle className="text-xl font-bold flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                            <User className="w-4 h-4 text-primary" />
                        </div>
                        {clienteToEdit ? 'Editar Cliente' : 'Novo Cliente'}
                    </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    {/* Nome */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            Nome *
                        </Label>
                        <Input
                            value={nome}
                            onChange={(e) => setNome(e.target.value)}
                            placeholder="Nome completo do cliente"
                            className="input-field"
                            required
                        />
                    </div>

                    {/* Telefone */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-muted-foreground" />
                            Telefone
                        </Label>
                        <Input
                            value={telefone}
                            onChange={handlePhoneChange}
                            placeholder="(00) 00000-0000"
                            className="input-field"
                            maxLength={15}
                        />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                            Email
                        </Label>
                        <Input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="email@exemplo.com"
                            className="input-field"
                        />
                    </div>

                    {/* Endereço */}
                    <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-muted-foreground" />
                            Endereço
                        </Label>
                        <Input
                            value={endereco}
                            onChange={(e) => setEndereco(e.target.value)}
                            placeholder="Rua, número, bairro"
                            className="input-field"
                        />
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t border-border">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() => onOpenChange(false)}
                            disabled={isLoading}
                        >
                            Cancelar
                        </Button>
                        <Button
                            type="submit"
                            variant="glow"
                            disabled={isLoading || !nome.trim()}
                        >
                            {isLoading ? 'Salvando...' : (clienteToEdit ? 'Salvar Alterações' : 'Cadastrar Cliente')}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}
