import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useItensOrcamento } from '@/hooks/useItensOrcamento';
import { useEstoque } from '@/hooks/useEstoque';
import { Loader2, Plus, Trash2, Package, Wrench } from 'lucide-react';
import { OrdemServico } from '@/types';
import { format } from 'date-fns';

interface OSDetailsDialogProps {
    os: OrdemServico | null;
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export function OSDetailsDialog({ os, open, onOpenChange }: OSDetailsDialogProps) {
    const { itens, isLoading: loadingItens, createItem, deleteItem } = useItensOrcamento(os?.id);
    const { data: estoque } = useEstoque();

    const [tipo, setTipo] = useState<'peca' | 'servico'>('peca');
    const [pecaId, setPecaId] = useState('');
    const [descricao, setDescricao] = useState('');
    const [quantidade, setQuantidade] = useState(1);
    const [valorUnitario, setValorUnitario] = useState(0);

    const handleAddItem = () => {
        if (!os?.id) return;

        let itemDescricao = descricao;
        let itemValor = valorUnitario;

        if (tipo === 'peca' && pecaId) {
            const peca = estoque?.find(p => p.id === pecaId);
            if (peca) {
                itemDescricao = peca.nome;
                itemValor = peca.preco_venda || 0;
            }
        }

        createItem.mutate({
            os_id: os.id,
            peca_id: tipo === 'peca' ? pecaId : null,
            descricao: itemDescricao,
            quantidade,
            valor_unitario: itemValor,
            tipo,
        }, {
            onSuccess: () => {
                setDescricao('');
                setQuantidade(1);
                setValorUnitario(0);
                setPecaId('');
            }
        });
    };

    const totalPecas = itens?.filter(i => i.tipo === 'peca').reduce((acc, i) => acc + i.subtotal, 0) || 0;
    const totalServicos = itens?.filter(i => i.tipo === 'servico').reduce((acc, i) => acc + i.subtotal, 0) || 0;
    const totalGeral = totalPecas + totalServicos;

    if (!os) return null;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto glass-card">
                <DialogHeader>
                    <DialogTitle className="flex items-center justify-between">
                        <span>Ordem de Serviço #{os.numero}</span>
                        <span className="text-sm font-normal text-muted-foreground">
                            {format(new Date(os.dataEntrada), 'dd/MM/yyyy')}
                        </span>
                    </DialogTitle>
                </DialogHeader>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div className="space-y-1">
                        <Label className="text-muted-foreground">Cliente</Label>
                        <p className="font-medium text-lg">{os.cliente?.nome || 'N/A'}</p>
                    </div>
                    <div className="space-y-1">
                        <Label className="text-muted-foreground">Veículo</Label>
                        <p className="font-medium text-lg">{os.veiculo?.modelo} - {os.veiculo?.placa}</p>
                    </div>
                    <div className="space-y-1 md:col-span-2">
                        <Label className="text-muted-foreground">Descrição do Problema</Label>
                        <p className="text-foreground">{os.descricao}</p>
                    </div>
                </div>

                <div className="border-t border-border/50 pt-6">
                    <h3 className="text-lg font-semibold mb-4">Itens do Orçamento</h3>

                    {/* Add Item Form */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-6 p-4 bg-muted/20 rounded-lg items-end">
                        <div className="md:col-span-2">
                            <Label>Tipo</Label>
                            <Select value={tipo} onValueChange={(v: 'peca' | 'servico') => setTipo(v)}>
                                <SelectTrigger className="input-field">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="peca">Peça</SelectItem>
                                    <SelectItem value="servico">Serviço</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {tipo === 'peca' ? (
                            <div className="md:col-span-4">
                                <Label>Peça</Label>
                                <Select value={pecaId} onValueChange={(v) => {
                                    setPecaId(v);
                                    const peca = estoque?.find(p => p.id === v);
                                    if (peca) setValorUnitario(peca.preco_venda || 0);
                                }}>
                                    <SelectTrigger className="input-field">
                                        <SelectValue placeholder="Selecione a peça" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {estoque?.map(p => (
                                            <SelectItem key={p.id} value={p.id}>{p.nome} (Est: {p.quantidade})</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        ) : (
                            <div className="md:col-span-4">
                                <Label>Descrição do Serviço</Label>
                                <Input
                                    value={descricao}
                                    onChange={e => setDescricao(e.target.value)}
                                    className="input-field"
                                    placeholder="Ex: Mão de obra"
                                />
                            </div>
                        )}

                        <div className="md:col-span-2">
                            <Label>Qtd</Label>
                            <Input
                                type="number"
                                min="1"
                                value={quantidade}
                                onChange={e => setQuantidade(Number(e.target.value))}
                                className="input-field"
                            />
                        </div>

                        <div className="md:col-span-2">
                            <Label>Valor Unit.</Label>
                            <Input
                                type="number"
                                min="0"
                                step="0.01"
                                value={valorUnitario}
                                onChange={e => setValorUnitario(Number(e.target.value))}
                                className="input-field"
                            />
                        </div>

                        <div className="md:col-span-2">
                            <Button
                                onClick={handleAddItem}
                                disabled={createItem.isPending}
                                className="w-full"
                                variant="glow"
                            >
                                {createItem.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                                Adicionar
                            </Button>
                        </div>
                    </div>

                    {/* Items List */}
                    {loadingItens ? (
                        <div className="flex justify-center py-8">
                            <Loader2 className="w-8 h-8 animate-spin text-primary" />
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="rounded-lg border border-border/50 overflow-hidden">
                                <table className="w-full text-sm">
                                    <thead className="bg-muted/30">
                                        <tr>
                                            <th className="p-3 text-left">Tipo</th>
                                            <th className="p-3 text-left">Descrição</th>
                                            <th className="p-3 text-center">Qtd</th>
                                            <th className="p-3 text-right">Valor Unit.</th>
                                            <th className="p-3 text-right">Subtotal</th>
                                            <th className="p-3 text-center">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {itens?.map((item) => (
                                            <tr key={item.id} className="border-t border-border/30">
                                                <td className="p-3">
                                                    {item.tipo === 'peca' ? (
                                                        <span className="flex items-center gap-2 text-primary">
                                                            <Package className="w-4 h-4" /> Peça
                                                        </span>
                                                    ) : (
                                                        <span className="flex items-center gap-2 text-info">
                                                            <Wrench className="w-4 h-4" /> Serviço
                                                        </span>
                                                    )}
                                                </td>
                                                <td className="p-3">{item.descricao}</td>
                                                <td className="p-3 text-center">{item.quantidade}</td>
                                                <td className="p-3 text-right">R$ {item.valor_unitario.toFixed(2)}</td>
                                                <td className="p-3 text-right font-medium">R$ {item.subtotal.toFixed(2)}</td>
                                                <td className="p-3 text-center">
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="h-8 w-8 text-destructive hover:text-destructive/80"
                                                        onClick={() => deleteItem.mutate(item.id)}
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))}
                                        {(!itens || itens.length === 0) && (
                                            <tr>
                                                <td colSpan={6} className="p-8 text-center text-muted-foreground">
                                                    Nenhum item adicionado ao orçamento
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                    <tfoot className="bg-muted/50 font-medium">
                                        <tr>
                                            <td colSpan={4} className="p-3 text-right">Total Peças:</td>
                                            <td className="p-3 text-right">R$ {totalPecas.toFixed(2)}</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colSpan={4} className="p-3 text-right">Total Serviços:</td>
                                            <td className="p-3 text-right">R$ {totalServicos.toFixed(2)}</td>
                                            <td></td>
                                        </tr>
                                        <tr className="text-lg border-t border-border">
                                            <td colSpan={4} className="p-4 text-right font-bold">Total Geral:</td>
                                            <td className="p-4 text-right font-bold text-primary">R$ {totalGeral.toFixed(2)}</td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}
