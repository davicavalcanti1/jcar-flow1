export interface Cliente {
  id: string;
  nome: string;
  telefone: string;
  endereco?: string;
  email?: string;
  createdAt: Date;
}

export interface Veiculo {
  id: string;
  clienteId: string;
  modelo: string;
  placa: string;
  ano: string;
  cor?: string;
  km?: number;
}

export type OSStatus = 
  | 'a_receber' 
  | 'aguardando_aprovacao' 
  | 'aguardando_peca' 
  | 'em_execucao' 
  | 'finalizado' 
  | 'pronto_retirada';

export interface OrdemServico {
  id: string;
  numero: string;
  clienteId: string;
  veiculoId: string;
  cliente?: Cliente;
  veiculo?: Veiculo;
  descricao: string;
  status: OSStatus;
  dataEntrada: Date;
  dataPrevista?: Date;
  dataFinal?: Date;
  mecanico?: string;
  valorTotal: number;
  fotos?: string[];
  observacoes?: string;
}

export interface ItemOrcamento {
  id: string;
  osId: string;
  tipo: 'peca' | 'mao_de_obra';
  descricao: string;
  quantidade: number;
  valorUnitario: number;
  subtotal: number;
}

export interface Peca {
  id: string;
  codigo: string;
  nome: string;
  quantidade: number;
  minimo: number;
  precoCompra: number;
  precoVenda: number;
  fornecedor?: string;
}

export interface Mecanico {
  id: string;
  nome: string;
  especialidade?: string;
  ativo: boolean;
}

export const STATUS_CONFIG: Record<OSStatus, { label: string; color: string; bgColor: string }> = {
  a_receber: { 
    label: 'A Receber', 
    color: 'text-info', 
    bgColor: 'bg-info/20' 
  },
  aguardando_aprovacao: { 
    label: 'Aguardando Aprovação', 
    color: 'text-warning', 
    bgColor: 'bg-warning/20' 
  },
  aguardando_peca: { 
    label: 'Aguardando Peça', 
    color: 'text-destructive', 
    bgColor: 'bg-destructive/20' 
  },
  em_execucao: { 
    label: 'Em Execução', 
    color: 'text-primary', 
    bgColor: 'bg-primary/20' 
  },
  finalizado: { 
    label: 'Finalizado', 
    color: 'text-success', 
    bgColor: 'bg-success/20' 
  },
  pronto_retirada: { 
    label: 'Pronto para Retirada', 
    color: 'text-success', 
    bgColor: 'bg-success/30' 
  },
};
