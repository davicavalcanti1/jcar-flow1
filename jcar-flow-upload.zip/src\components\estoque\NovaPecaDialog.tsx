import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCreatePeca, useUpdatePeca } from '@/hooks/useEstoque';
import { Package, Hash, DollarSign, TrendingUp } from 'lucide-react';
import { Database } from '@/integrations/supabase/types';

type Peca = Database['public']['Tables']['estoque']['Row'];

interface NovaPecaDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    pecaToEdit?: Peca | null;
}

export function NovaPecaDialog({ open, onOpenChange, pecaToEdit }: NovaPecaDialogProps) {
    const [codigo, setCodigo] = useState('');
    const [nome, setNome] = useState('');
    const [quantidade, setQuantidade] = useState('0');
    const [quantidadeMinima, setQuantidadeMinima] = useState('');
    const [precoCompra, setPrecoCompra] = useState('');
    const [precoVenda, setPrecoVenda] = useState('');
    const [fornecedor, setFornecedor] = useState('');

    const createPeca = useCreatePeca();
    const updatePeca = useUpdatePeca();

    useEffect(() => {
        if (pecaToEdit) {
            setCodigo(pecaToEdit.codigo || '');
            setNome(pecaToEdit.nome);
            setQuantidade(pecaToEdit.quantidade.toString());
            setQuantidadeMinima(pecaToEdit.quantidade_minima ? pecaToEdit.quantidade_minima.toString() : '');
            setPrecoCompra(pecaToEdit.preco_compra ? pecaToEdit.preco_compra.toString() : '');
            setPrecoVenda(pecaToEdit.preco_venda ? pecaToEdit.preco_venda.toString() : '');
            setFornecedor(pecaToEdit.fornecedor || '');
        } else {
            setCodigo('');
            setNome('');
            setQuantidade('0');
            setQuantidadeMinima('');
            setPrecoCompra('');
            setPrecoVenda('');
            setFornecedor('');
        }
    }, [pecaToEdit, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!nome.trim()) {
            return;
        }

        try {
            if (pecaToEdit) {
                await updatePeca.mutateAsync({
                    id: pecaToEdit.id,
                    codigo: codigo.trim() || undefined,
                    nome: nome.trim(),
                    quantidade: parseInt(quantidade) || 0,
                    quantidade_minima: quantidadeMinima ? parseInt(quantidadeMinima) : undefined,
                    preco_compra: precoCompra ? parseFloat(precoCompra) : undefined,
                    preco_venda: precoVenda ? parseFloat(precoVenda) : undefined,
                    fornecedor: fornecedor.trim() || undefined,
                });
            } else {
                await createPeca.mutateAsync({
                    codigo: codigo.trim() || undefined,
                    nome: nome.trim(),
                    quantidade: parseInt(quantidade) || 0,
                    quantidade_minima: quantidadeMinima ? parseInt(quantidadeMinima) : undefined,
                    preco_compra: precoCompra ? parseFloat(precoCompra) : undefined,
                    preco_venda: precoVenda ? parseFloat(precoVenda) : undefined,
                    fornecedor: fornecedor.trim() || undefined,
                });
            }

            // Reset form and close dialog
            setCodigo('');
            setNome('');
            setQuantidade('0');
            setQuantidadeMinima('');
            setPrecoCompra('');
            setPrecoVenda('');
            setFornecedor('');
            onOpenChange(false);
        } catch (error) {
            console.error(error);
        }
    };

    const formatCurrency = (value: string) => {
        const numbers = value.replace(/\D/g, '');
        const amount = parseFloat(numbers) / 100;
        return amount.toFixed(2);
    };

    const handlePrecoChange = (value: string, setter: (val: string) => void) => {
        const formatted = formatCurrency(value);
        setter(formatted);
    };

    const margemLucro = precoCompra && precoVenda
        ? ((parseFloat(precoVenda) - parseFloat(precoCompra)) / parseFloat(precoCompra) * 100).toFixed(1)
        : null;

    const isLoading = createPeca.isPending || updatePeca.isPending;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-md bg-card border-border">
                <DialogHeader>
                    <DialogTitle className="text-xl font-bold flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                            <Package className="w-4 h-4 text-primary" />
                        </div>
                        {pecaToEdit ? 'Editar Peça' : 'Nova Peça'}
                    </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    {/* Código e Nome */}
                    <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <Hash className="w-4 h-4 text-muted-foreground" />
                                Código
                            </Label>
                            <Input
                                value={codigo}
                                onChange={(e) => setCodigo(e.target.value)}
                                placeholder="Auto"
                                className="input-field"
                            />
                        </div>

                        <div className="space-y-2 col-span-2">
                            <Label className="flex items-center gap-2">
                                <Package className="w-4 h-4 text-muted-foreground" />
                                Nome *
                            </Label>
                            <Input
                                value={nome}
                                onChange={(e) => setNome(e.target.value)}
                                placeholder="Nome da peça"
                                className="input-field"
                                required
                            />
                        </div>
                    </div>

                    {/* Quantidades */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Quantidade</Label>
                            <Input
                                type="number"
                                value={quantidade}
                                onChange={(e) => setQuantidade(e.target.value)}
                                placeholder="0"
                                className="input-field"
                                min="0"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label>Qtd. Mínima</Label>
                            <Input
                                type="number"
                                value={quantidadeMinima}
                                onChange={(e) => setQuantidadeMinima(e.target.value)}
                                placeholder="0"
                                className="input-field"
                                min="0"
                            />
                        </div>
                    </div>

                    {/* Preços */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <DollarSign className="w-4 h-4 text-muted-foreground" />
                                Preço Compra
                            </Label>
                            <Input
                                type="number"
                                step="0.01"
                                value={precoCompra}
                                onChange={(e) => setPrecoCompra(e.target.value)}
                                placeholder="0.00"
                                className="input-field"
                                min="0"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label className="flex items-center gap-2">
                                <DollarSign className="w-4 h-4 text-muted-foreground" />
                                Preço Venda
                            </Label>
                            <Input
                                type="number"
                                step="0.01"
                                value={precoVenda}
                                onChange={(e) => setPrecoVenda(e.target.value)}
                                placeholder="0.00"
                                className="input-field"
                                min="0"
                            />
                        </div>
                    </div>

                    {/* Margem de Lucro */}
                    {margemLucro && (
                        <div className="flex items-center gap-2 text-sm p-3 bg-muted/50 rounded-lg">
                            <TrendingUp className="w-4 h-4 text-success" />
                            <span className="text-muted-foreground">Margem de lucro:</span>
                            <span className="font-semibold text-success">{margemLucro}%</span>
                        </div>
                    )}

                    {/* Fornecedor */}
                    <div className="space-y-2">
                        <Label>Fornecedor</Label>
                        <Input
                            value={fornecedor}
                            onChange={(e) => setFornecedor(e.target.value)}
                            placeholder="Nome do fornecedor"
                            className="input-field"
                        />
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t border-border">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() => onOpenChange(false)}
                            disabled={isLoading}
                        >
                            Cancelar
                        </Button>
                        <Button
                            type="submit"
                            variant="glow"
                            disabled={isLoading || !nome.trim()}
                        >
                            {isLoading ? 'Salvando...' : (pecaToEdit ? 'Salvar Alterações' : 'Cadastrar Peça')}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}
