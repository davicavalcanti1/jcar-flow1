import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useClientes } from '@/hooks/useClientes';
import { useVeiculosByCliente } from '@/hooks/useVeiculos';
import { useMecanicos } from '@/hooks/useMecanicos';
import { useCreateOrdemServico } from '@/hooks/useOrdensServico';
import { Camera, Car, User, Wrench, Calendar } from 'lucide-react';

interface NovaOSDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function NovaOSDialog({ open, onOpenChange }: NovaOSDialogProps) {
  const [clienteId, setClienteId] = useState('');
  const [veiculoId, setVeiculoId] = useState('');
  const [descricao, setDescricao] = useState('');
  const [mecanicoId, setMecanicoId] = useState('');
  const [dataPrevista, setDataPrevista] = useState('');

  const { data: clientes, isLoading: loadingClientes } = useClientes();
  const { data: veiculos, isLoading: loadingVeiculos } = useVeiculosByCliente(clienteId);
  const { data: mecanicos, isLoading: loadingMecanicos } = useMecanicos();
  const createOS = useCreateOrdemServico();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!clienteId || !veiculoId || !descricao.trim()) {
      return;
    }

    try {
      await createOS.mutateAsync({
        cliente_id: clienteId,
        veiculo_id: veiculoId,
        descricao: descricao.trim(),
        mecanico_id: mecanicoId || undefined,
        data_prevista: dataPrevista || undefined,
      });

      // Reset form and close dialog
      setClienteId('');
      setVeiculoId('');
      setDescricao('');
      setMecanicoId('');
      setDataPrevista('');
      onOpenChange(false);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Wrench className="w-4 h-4 text-primary" />
            </div>
            Nova Ordem de Serviço
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Cliente e Veículo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                Cliente *
              </Label>
              <Select
                value={clienteId}
                onValueChange={(v) => { setClienteId(v); setVeiculoId(''); }}
                disabled={loadingClientes}
              >
                <SelectTrigger className="input-field">
                  <SelectValue placeholder={loadingClientes ? "Carregando..." : "Selecione o cliente"} />
                </SelectTrigger>
                <SelectContent>
                  {clientes?.map(cliente => (
                    <SelectItem key={cliente.id} value={cliente.id}>
                      {cliente.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Car className="w-4 h-4 text-muted-foreground" />
                Veículo *
              </Label>
              <Select
                value={veiculoId}
                onValueChange={setVeiculoId}
                disabled={!clienteId || loadingVeiculos}
              >
                <SelectTrigger className="input-field">
                  <SelectValue placeholder={clienteId ? (loadingVeiculos ? "Carregando..." : "Selecione o veículo") : "Selecione um cliente primeiro"} />
                </SelectTrigger>
                <SelectContent>
                  {veiculos?.map(veiculo => (
                    <SelectItem key={veiculo.id} value={veiculo.id}>
                      {veiculo.modelo} - {veiculo.placa}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Descrição */}
          <div className="space-y-2">
            <Label>Reclamação / Descrição do Serviço *</Label>
            <Textarea
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Descreva o problema ou serviço a ser realizado..."
              className="input-field min-h-[100px]"
              required
            />
          </div>

          {/* Mecânico e Data */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-muted-foreground" />
                Mecânico Responsável
              </Label>
              <Select
                value={mecanicoId}
                onValueChange={setMecanicoId}
                disabled={loadingMecanicos}
              >
                <SelectTrigger className="input-field">
                  <SelectValue placeholder="Selecione (opcional)" />
                </SelectTrigger>
                <SelectContent>
                  {mecanicos?.map(mecanico => (
                    <SelectItem key={mecanico.id} value={mecanico.id}>
                      {mecanico.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                Previsão de Entrega
              </Label>
              <Input
                type="date"
                value={dataPrevista}
                onChange={(e) => setDataPrevista(e.target.value)}
                className="input-field"
              />
            </div>
          </div>

          {/* Fotos */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-muted-foreground" />
              Fotos (opcional)
            </Label>
            <div className="border-2 border-dashed border-border/50 rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <Camera className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                Clique para adicionar fotos do veículo
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-border">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={createOS.isPending}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="glow"
              disabled={createOS.isPending || !clienteId || !veiculoId || !descricao.trim()}
            >
              {createOS.isPending ? 'Criando...' : 'Criar Ordem de Serviço'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
