import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export type OSStatus =
    | 'a_receber'
    | 'aguardando_aprovacao'
    | 'aguardando_peca'
    | 'em_execucao'
    | 'finalizado'
    | 'pronto_retirada';

export interface OrdemServico {
    id: string;
    numero: string;
    cliente_id: string | null;
    veiculo_id: string | null;
    mecanico_id: string | null;
    descricao: string | null;
    observacoes: string | null;
    status: string;
    data_entrada: string;
    data_prevista: string | null;
    data_conclusao: string | null;
    valor_total: number | null;
    created_at: string;
    updated_at: string;
}

export interface OrdemServicoWithRelations extends OrdemServico {
    cliente?: {
        id: string;
        nome: string;
        telefone: string | null;
    };
    veiculo?: {
        id: string;
        modelo: string;
        placa: string;
    };
    mecanico?: {
        id: string;
        nome: string;
    };
}

export interface CreateOrdemServicoData {
    cliente_id: string;
    veiculo_id: string;
    mecanico_id?: string;
    descricao: string;
    data_prevista?: string;
    observacoes?: string;
}

// Generate OS number in format OS-YYYY-NNN
async function generateOSNumber(): Promise<string> {
    const year = new Date().getFullYear();
    const prefix = `OS-${year}-`;

    // Get the last OS number for this year
    const { data, error } = await supabase
        .from('ordens_servico')
        .select('numero')
        .like('numero', `${prefix}%`)
        .order('numero', { ascending: false })
        .limit(1);

    if (error) throw error;

    let nextNumber = 1;
    if (data && data.length > 0) {
        const lastNumber = parseInt(data[0].numero.split('-')[2]);
        nextNumber = lastNumber + 1;
    }

    return `${prefix}${nextNumber.toString().padStart(3, '0')}`;
}

// Fetch all service orders with relations
export function useOrdensServico() {
    return useQuery({
        queryKey: ['ordens_servico'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('ordens_servico')
                .select(`
          *,
          cliente:clientes(id, nome, telefone),
          veiculo:veiculos(id, modelo, placa),
          mecanico:mecanicos(id, nome)
        `)
                .order('data_entrada', { ascending: false });

            if (error) throw error;
            return data as OrdemServicoWithRelations[];
        },
    });
}

// Fetch single service order
export function useOrdemServico(id: string | null) {
    return useQuery({
        queryKey: ['ordens_servico', id],
        queryFn: async () => {
            if (!id) return null;

            const { data, error } = await supabase
                .from('ordens_servico')
                .select(`
          *,
          cliente:clientes(id, nome, telefone),
          veiculo:veiculos(id, modelo, placa),
          mecanico:mecanicos(id, nome)
        `)
                .eq('id', id)
                .single();

            if (error) throw error;
            return data as OrdemServicoWithRelations;
        },
        enabled: !!id,
    });
}

// Create new service order
export function useCreateOrdemServico() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (newOS: CreateOrdemServicoData) => {
            const numero = await generateOSNumber();

            const { data, error } = await supabase
                .from('ordens_servico')
                .insert([{
                    ...newOS,
                    numero,
                    status: 'a_receber',
                    data_entrada: new Date().toISOString(),
                }])
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] });
            toast.success('Ordem de serviço criada com sucesso!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao criar ordem de serviço: ' + error.message);
        },
    });
}

// Update service order
export function useUpdateOrdemServico() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, ...updates }: Partial<OrdemServico> & { id: string }) => {
            const { data, error } = await supabase
                .from('ordens_servico')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] });
            toast.success('Ordem de serviço atualizada!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao atualizar ordem de serviço: ' + error.message);
        },
    });
}

// Update service order status (for drag and drop)
export function useUpdateOrdemServicoStatus() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ id, status }: { id: string; status: OSStatus }) => {
            const updates: any = { status };

            // Set data_conclusao when status is finalizado or pronto_retirada
            if (status === 'finalizado' || status === 'pronto_retirada') {
                updates.data_conclusao = new Date().toISOString();
            }

            const { data, error } = await supabase
                .from('ordens_servico')
                .update(updates)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] });
        },
        onError: (error: Error) => {
            toast.error('Erro ao atualizar status: ' + error.message);
        },
    });
}

// Delete service order
export function useDeleteOrdemServico() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase
                .from('ordens_servico')
                .delete()
                .eq('id', id);

            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['ordens_servico'] });
            toast.success('Ordem de serviço excluída!');
        },
        onError: (error: Error) => {
            toast.error('Erro ao excluir ordem de serviço: ' + error.message);
        },
    });
}
