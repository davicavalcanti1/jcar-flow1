-- Tabela de Clientes
CREATE TABLE public.clientes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  telefone TEXT,
  endereco TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de Mecânicos
CREATE TABLE public.mecanicos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  especialidade TEXT,
  telefone TEXT,
  ativo BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de Veículos
CREATE TABLE public.veiculos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cliente_id UUID REFERENCES public.clientes(id) ON DELETE CASCADE,
  modelo TEXT NOT NULL,
  marca TEXT,
  placa TEXT NOT NULL,
  ano INTEGER,
  cor TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de Estoque/Peças
CREATE TABLE public.estoque (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  codigo TEXT,
  nome TEXT NOT NULL,
  quantidade INTEGER NOT NULL DEFAULT 0,
  quantidade_minima INTEGER DEFAULT 5,
  preco_compra DECIMAL(10,2),
  preco_venda DECIMAL(10,2),
  fornecedor TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de Ordens de Serviço
CREATE TABLE public.ordens_servico (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  numero TEXT NOT NULL UNIQUE,
  cliente_id UUID REFERENCES public.clientes(id),
  veiculo_id UUID REFERENCES public.veiculos(id),
  mecanico_id UUID REFERENCES public.mecanicos(id),
  descricao TEXT,
  status TEXT NOT NULL DEFAULT 'a_receber',
  data_entrada TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  data_prevista TIMESTAMP WITH TIME ZONE,
  data_conclusao TIMESTAMP WITH TIME ZONE,
  valor_total DECIMAL(10,2) DEFAULT 0,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de Itens do Orçamento
CREATE TABLE public.itens_orcamento (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  os_id UUID REFERENCES public.ordens_servico(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL, -- 'peca' ou 'mao_de_obra'
  descricao TEXT NOT NULL,
  quantidade INTEGER NOT NULL DEFAULT 1,
  valor_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  peca_id UUID REFERENCES public.estoque(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mecanicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.veiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estoque ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ordens_servico ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_orcamento ENABLE ROW LEVEL SECURITY;

-- Políticas públicas para leitura e escrita (sistema sem autenticação por enquanto)
CREATE POLICY "Permitir leitura pública de clientes" ON public.clientes FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de clientes" ON public.clientes FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de clientes" ON public.clientes FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de clientes" ON public.clientes FOR DELETE USING (true);

CREATE POLICY "Permitir leitura pública de mecanicos" ON public.mecanicos FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de mecanicos" ON public.mecanicos FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de mecanicos" ON public.mecanicos FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de mecanicos" ON public.mecanicos FOR DELETE USING (true);

CREATE POLICY "Permitir leitura pública de veiculos" ON public.veiculos FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de veiculos" ON public.veiculos FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de veiculos" ON public.veiculos FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de veiculos" ON public.veiculos FOR DELETE USING (true);

CREATE POLICY "Permitir leitura pública de estoque" ON public.estoque FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de estoque" ON public.estoque FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de estoque" ON public.estoque FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de estoque" ON public.estoque FOR DELETE USING (true);

CREATE POLICY "Permitir leitura pública de ordens_servico" ON public.ordens_servico FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de ordens_servico" ON public.ordens_servico FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de ordens_servico" ON public.ordens_servico FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de ordens_servico" ON public.ordens_servico FOR DELETE USING (true);

CREATE POLICY "Permitir leitura pública de itens_orcamento" ON public.itens_orcamento FOR SELECT USING (true);
CREATE POLICY "Permitir inserção pública de itens_orcamento" ON public.itens_orcamento FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir atualização pública de itens_orcamento" ON public.itens_orcamento FOR UPDATE USING (true);
CREATE POLICY "Permitir exclusão pública de itens_orcamento" ON public.itens_orcamento FOR DELETE USING (true);

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON public.clientes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_veiculos_updated_at BEFORE UPDATE ON public.veiculos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_estoque_updated_at BEFORE UPDATE ON public.estoque FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_ordens_servico_updated_at BEFORE UPDATE ON public.ordens_servico FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Inserir alguns mecânicos iniciais
INSERT INTO public.mecanicos (nome, especialidade) VALUES 
  ('Carlos Silva', 'Motor'),
  ('João Santos', 'Suspensão'),
  ('Pedro Oliveira', 'Elétrica');